#include <iostream>
#include <fstream>
using namespace std;

void rowWiseSum(float** matrix, int rows, int* colSizes) {
    cout << "Sum row wise: ";
    for (int i = 0; i < rows; ++i) {
        float sum = 0;
        for (int j = 0; j < colSizes[i]; ++j) {
            sum = sum + matrix[i][j];
        }
        cout << sum;
        if (i < rows - 1) cout << ", ";
    }
    cout << endl;
}

void colWiseSum(float** matrix, int rows, int maxCols, int* colSizes) {
    cout << "Sum col wise: ";
    for (int j = 0; j < maxCols; ++j) {
        float sum = 0;
        for (int i = 0; i < rows; ++i) {
            if (j < colSizes[i]) {
                sum = sum + matrix[i][j];
            }
        }
        cout << sum;
        if (j < maxCols - 1) cout << ", ";
    }
    cout << endl;
}

void diagonalSum(float** matrix, int rows, int* colSizes) {
    bool isPossible = true;
    for (int i = 0; i < rows; ++i) {
        if (colSizes[i] <= i) {
            isPossible = false;
            break;
        }
    }

    if (!isPossible) {
        cout << "Sum diagonal wise: Not Possible" << endl;
    }
    else {
        float sum = 0;
        for (int i = 0; i < rows; ++i) {
            sum += matrix[i][i];
        }
        cout << "Sum diagonal wise: " << sum << endl;
    }
}

void reverseDiagonalSum(float** matrix, int rows, int* colSizes) {
    bool isPossible = true;
    for (int i = 0; i < rows; ++i) {
        if (colSizes[i] <= (rows - i - 1)) {
            isPossible = false;
            break;
        }
    }

    if (!isPossible) {
        cout << "Sum reverse diagonal: Not Possible" << endl;
    }
    else {
        float sum = 0;
        for (int i = 0; i < rows; ++i) {
            sum += matrix[i][rows - i - 1];
        }
        cout << "Sum reverse diagonal: " << sum << endl;
    }
}

int main() {
    string filename;
    cout << "Enter the filename: ";
    cin >> filename;

    ifstream infile(filename);
   
    int rows;
    infile >> rows;

    float** matrix = new float* [rows];
    int* colSizes = new int[rows];

    int maxCols = 0;
    for (int i = 0; i < rows; ++i) {
        infile >> colSizes[i];
        if (colSizes[i] > maxCols) {
            maxCols = colSizes[i];
        }

        matrix[i] = new float[colSizes[i]];
        for (int j = 0; j < colSizes[i]; ++j) {
            infile >> matrix[i][j];
        }
    }

    infile.close();

    rowWiseSum(matrix, rows, colSizes);
    colWiseSum(matrix, rows, maxCols, colSizes);
    diagonalSum(matrix, rows, colSizes);
    reverseDiagonalSum(matrix, rows, colSizes);

    for (int i = 0; i < rows; ++i) {
        delete[] matrix[i];
    }
    delete[] matrix;
    delete[] colSizes;

    return 0;
}