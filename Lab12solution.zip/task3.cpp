#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream inputFile("Data.txt");
    if (!inputFile) {
        cout << "Error opening file." << endl;
        return 1;
    }

    int matrix[100][100]; 
    int row = 0, col = 0, maxDim = 0;
    int num;

    while (inputFile >> num)
    {
        if (num == -99)
        {
            maxDim = max(maxDim, col);
            row++;
            col = 0;
        }
        else
        {
            matrix[row][col++] = num;
        }
    }

    maxDim = max(maxDim, col); 
    inputFile.close();

    for (int i = 0; i < maxDim; ++i)
    {
        cout << matrix[i][i] << " ";
    }
    cout << endl;

    return 0;
}
