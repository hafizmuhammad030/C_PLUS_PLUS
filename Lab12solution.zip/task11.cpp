#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    char ids[100][10];
    char names[100][20];
    int count = 0;

    ifstream inputFile("Data.txt");
    while (inputFile >> ids[count] >> names[count]) {
        count++;
    }

    for (int i = 0; i < count; i++) {
        cout << ids[i] << " ";
        for (int j = 0; names[i][j]; j++) {
            char c = names[i][j];
            if (c != 'a' && c != 'e' && c != 'i' && c != 'o' && c != 'u' &&
                c != 'A' && c != 'E' && c != 'I' && c != 'O' && c != 'U') {
                cout << c;
            }
        }
        cout << endl;
    }

    int index = 0;
    for (int i = 0; i < count; i++) {
        int j = 0;
        while (names[i][j]) {
            char c = names[i][j];
            if (c != 'a' && c != 'e' && c != 'i' && c != 'o' && c != 'u' &&
                c != 'A' && c != 'E' && c != 'I' && c != 'O' && c != 'U') {
                names[index][j] = c;
                j++;
            }
            else {
                names[index][j] = '\0';
                break;
            }
        }
        index++;
    }

    for (int i = 0; i < index; i++) {
        cout << ids[i] << " " << names[i] << endl;
    }

    return 0;
}

