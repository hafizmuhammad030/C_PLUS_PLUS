#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream inputFile("Data.txt");
    int num;
    int row = 0;
    int col = 0;
    int maxCols = 0;

   
    while (inputFile >> num) {
        if (num == -99) {
            row++;
            col = 0;
        }
        else {
            col++;
            maxCols = max(maxCols, col);
        }
    }

    inputFile.close();
    inputFile.open("Data.txt");

   
    for (int i = 0; i < maxCols; i++) {
        for (int j = 0; j < row; j++) {
            for (int k = 0; k <= i; k++) {
                inputFile >> num;
            }
            cout << num << " ";
            for (int k = i + 1; k < maxCols; k++) {
                inputFile >> num;
            }
            inputFile >> num; 
        }
        cout << "\n";
    }

    return 0;
}

