#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    string names[100];
    int count = 0;

    ifstream inputFile("Data.txt");
    while (inputFile >> names[count]) {
        count++;
    }

    cout << "List of Names: ";
    for (int i = 0; i < count; i++) {
        cout << names[i] << " ";
    }
    cout << endl;

    int row1, row2;
    cout << "Enter row numbers to swap (1-" << count << "): ";
    cin >> row1 >> row2;

    row1--; 
    row2--;

    if (row1 >= 0 && row1 < count && row2 >= 0 && row2 < count) {
        swap(names[row1], names[row2]);

        cout << "Selected " << row1 + 1 << " and " << row2 + 1 << " rows: ";
        for (int i = 0; i < count; i++) {
            cout << names[i] << " ";
        }
        cout << endl;
    }
    else {
        cout << "Invalid row numbers!" << endl;
    }

    return 0;
}

