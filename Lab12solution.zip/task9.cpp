#include <iostream>
#include <fstream>
using namespace std;

int main() 
{
    int data[100];
    int count = 0;
    int num;

    ifstream inputFile("Data.txt");
    while (inputFile >> num) {
        if (num == -99) {
            int temp;
            for (int i = 0; i < count; i++) {
                for (int j = i + 1; j < count; j++) {
                    if (data[i] > data[j]) {
                        temp = data[i];
                        data[i] = data[j];
                        data[j] = temp;
                    }
                }
            }
            ofstream outputFile("SortedData.txt", ios::app);
            for (int i = 0; i < count; i++) {
                outputFile << data[i] << " ";
            }
            outputFile << "-99\n";
            count = 0;
        }
        else {
            data[count] = num;
            count++;
        }
    }

    return 0;
}

