#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream inputFile("Data.txt");
    float num;
    float rowSum = 0;
    float colSum[5] = { 0 };

    int row = 0;
    int col = 0;

    while (inputFile >> num) 
    {
        if (num == -99) 
        {
            cout << "Sum row-wise: " << rowSum << endl;
            rowSum = 0;
            row++;
            col = 0;
        }
        else
        {
            rowSum += num;
            colSum[col] += num;
            col++;
        }
    }

    cout << "Sum row-wise: " << rowSum << endl;

    cout << "Sum column-wise: ";
    for (int i = 0; i < 5; i++) {
        cout << colSum[i] << " ";
    }

    return 0;
}

