#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream inputFile("Data.txt");
    if (!inputFile) {
        cerr << "Unable to open file Data.txt";
        return 1; 
    }

    int num;
    int row = 0;

    string secondRowNumbers = "";
    while (inputFile >> num)
    {
        if (num == -99)
        {
            row++;
        }
        else
        {
            if (row == 1)
            {
                cout << num << " ";
                secondRowNumbers += to_string(num) + " ";
            }
        }
    }
    cout << "\n";

    inputFile.close(); 

    inputFile.open("Data.txt"); 
    if (!inputFile) {
        cerr << "Unable to open file Data.txt";
        return 1; 
    }

    row = 0;
    while (inputFile >> num)
    {
        if (num == -99)
        {
            row++;
            cout << "-99\n";
        }
        else
        {
            cout << num << " ";
        }
    }

    cout << "\nSecond row numbers: " << secondRowNumbers << "\n";

    inputFile.close(); 

    return 0;
}
