#include <iostream>
#include <fstream>
using namespace std;

int main() 
{
    int data[100][100];
    int rows = 0;
    int cols = 0;
    int num;

    ifstream inputFile("Data.txt");
    while (inputFile >> num)
    {
        data[rows][cols] = num;
        cols++;
        if (num == -99)
        {
            rows++;
            cols = 0;
        }
    }

    cout << "Enter position to remove (row, col): ";
    int row, col;
    cin >> row >> col;

    for (int i = col; i < cols; i++)
    {
        data[row][i] = data[row][i + 1];
    }

    for (int i = row; i < rows; i++)
    {
        for (int j = 0; j < cols; j++) 
        {
            data[i][j] = data[i + 1][j];
        }
    }

    rows--;

    ofstream outputFile("UpdatedData.txt");
    for (int i = 0; i < rows; i++) 
    {
        for (int j = 0; j < cols; j++) 
        {
            outputFile << data[i][j] << " ";
        }
        outputFile << "-99\n";
    }

    return 0;
}
