#include <iostream>
#include <fstream>

using namespace std;

void readMatrix(ifstream& inputFile, int matrix[][100], int& rows, int& cols) {
    int num;
    rows = 0;
    cols = 0;
    int currentCols = 0;
    int row = 0, col = 0;

    while (inputFile >> num) {
        if (num == -99) {
            if (currentCols > cols) {
                cols = currentCols;
            }
            currentCols = 0;
            row++;
            rows++;
            col = 0;
        }
        else {
            matrix[row][col++] = num;
            currentCols++;
        }
    }

    if (currentCols > 0) {
        if (currentCols > cols) {
            cols = currentCols;
        }
        rows++;
    }
}

int main() {
    ifstream inputFile1("Matrix1.txt");
    ifstream inputFile2("Matrix2.txt");

    if (!inputFile1 || !inputFile2) {
        cout << "Error opening one of the files." << endl;
        return 1;
    }

    int row1 = 0, col1 = 0, row2 = 0, col2 = 0;
    int matrix1[100][100] = { 0 };
    int matrix2[100][100] = { 0 };

    readMatrix(inputFile1, matrix1, row1, col1);
    readMatrix(inputFile2, matrix2, row2, col2);

    if (row1 != row2 || col1 != col2) {
        cout << "Matrices are not the same size. Cannot calculate sum." << endl;
        return 1;
    }

    for (int i = 0; i < row1; i++) {
        for (int j = 0; j < col1; j++) {
            cout << matrix1[i][j] + matrix2[i][j] << " ";
        }
        cout << "-99\n";
    }

    return 0;
}
