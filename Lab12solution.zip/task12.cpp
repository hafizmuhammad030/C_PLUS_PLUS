#include <iostream>
#include <fstream>
using namespace std;

int main() {
    int data[100][100];
    int rows = 0;
    int cols = 0;
    int num;

    ifstream inputFile("Data.txt");
    while (inputFile >> num) {
        data[rows][cols] = num;
        cols++;
        if (num == -99) {
            rows++;
            cols = 0;
        }
    }

    cout << "Original Data:" << endl;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cout << data[i][j] << " ";
        }
        cout << endl;
    }

    int option;
    cout << "Enter 1 to remove a value, 2 to insert a value: ";
    cin >> option;

    if (option == 1) {
        cout << "Enter position to remove (row, col): ";
        int row, col;
        cin >> row >> col;
        // Remove value at position (row, col)
        for (int i = col; i < cols; i++) {
            data[row][i] = data[row][i + 1];
        }
        // Shift rows down
        for (int i = row; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                data[i][j] = data[i + 1][j];
            }
        }
        rows--;
    }
    else if (option == 2) {
        cout << "Enter position to insert (row, col): ";
        int row, col;
        cin >> row >> col;
        cout << "Enter value to insert: ";
        int val;
        cin >> val;
        // Insert value at position (row, col)
        for (int i = cols; i > col; i--) {
            data[row][i] = data[row][i - 1];
        }
        data[row][col] = val;
        cols++;
    }

    cout << "Updated Data:" << endl;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cout << data[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
