#include <iostream>
#include <fstream>
#include<string>
using namespace std;

int main() {
    string fname[100], lname[100], fullname[100];
    int count = 0;

    ifstream inputFile1("fname.txt");
    ifstream inputFile2("lname.txt");
    ofstream outputFile("fullnames.txt");

    string str;

    while (getline(inputFile1, str, ',')) {
        fname[count] = str;
        count++;
    }

    count = 0;

    while (getline(inputFile2, str, ',')) {
        lname[count] = str;
        count++;
    }

    for (int i = 0; i < 100; i++) {
        if (fname[i] != "" && lname[i] != "") {
            fullname[i] = fname[i] + " " + lname[i];
            outputFile << fullname[i] << endl;
        }
    }

    return 0;

}