#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream inputFile("Data.txt");
    float mark;
    float highest = 0;

    while (inputFile >> mark) {
        if (mark == -99) {
            cout << "Highest marks are " << highest << ", ";
            highest = 0;
        }
        else {
            if (mark > highest) {
                highest = mark;
            }
        }
    }

    cout << highest << endl;

    return 0;
}

