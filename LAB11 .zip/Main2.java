class SmartDevice {
    protected String name;
    protected boolean isOn;

    public SmartDevice(String name) {
        this.name = name;
        this.isOn = false;
    }

    public void turnOn() {
        isOn = true;
        System.out.println(name + " is turned on.");
    }

    public void turnOff() {
        isOn = false;
        System.out.println(name + " is turned off.");
    }

    public void displayStatus() {
        System.out.println(name + " is " + (isOn ? "ON" : "OFF"));
    }
}

class SmartLights extends SmartDevice {
    protected int brightness;

    public SmartLights(String name) {
        super(name);
        this.brightness = 0;
    }

    public void setBrightness(int brightness) {
        if (brightness >= 0 && brightness <= 100) {
            this.brightness = brightness;
            System.out.println(name + " brightness set to " + brightness);
        } else {
            System.out.println("Invalid brightness level.");
        }
    }

    @Override
    public void displayStatus() {
        System.out.println(name + " is " + (isOn ? "ON" : "OFF") + "\nBrightness: " + brightness);
    }
}

class SmartAirConditioner extends SmartDevice {
    protected int temperature;

    public SmartAirConditioner(String name) {
        super(name);
        this.temperature = 25;
    }

    public void setTemperature(int temperature) {
        if (temperature >= 16 && temperature <= 30) {
            this.temperature = temperature;
            System.out.println(name + " temperature set to " + temperature + "°C");
        } else {
            System.out.println("Invalid temperature.");
        }
    }

    @Override
    public void displayStatus() {
        System.out.println(name + " is " + (isOn ? "ON" : "OFF") + "\nTemperature: " + temperature + "°C");
    }
}

class SmartColorLights extends SmartLight {
    private String color;

    public SmartColorLights(String name, String color) {
        super(name);
        this.color = color;
    }

    public void setColor(String color) {
        this.color = color;
        System.out.println(name + " color set to " + color);
    }

    @Override
    public void displayStatus() {
        System.out.println(name + " is " + (isOn ? "ON" : "OFF") + "\nBrightness: " + brightness + "\nColor: " + color);
    }
}

class SmartCooler extends SmartAirConditioner {
    private String fanSpeed;

    public SmartCooler(String name) {
        super(name);
        this.fanSpeed = "Low";
    }

    public void setFanSpeed(String fanSpeed) {
        if (fanSpeed.equals("Low") || fanSpeed.equals("Medium") || fanSpeed.equals("High")) {
            this.fanSpeed = fanSpeed;
            System.out.println(name + " fan speed set to " + fanSpeed);
        } else {
            System.out.println("Invalid fan speed.");
        }
    }

    @Override
    public void displayStatus() {
        System.out.println(name + " is " + (isOn ? "ON" : "OFF") + "\nTemperature: " + temperature + "°C\nFan Speed: " + fanSpeed);
    }
}

public class Main2 {
    public static void main(String[] args) {
        SmartDevice genericDevice = new SmartDevice("Generic Device");
        SmartLight livingRoomLight = new SmartLight("Living Room Light");
        SmartColorLight bedroomColorLight = new SmartColorLight("Bedroom Color Light", "White");
        SmartAirConditioner livingRoomAC = new SmartAirConditioner("Living Room AC");
        SmartCooler garageCooler = new SmartCooler("Garage Cooler");

        genericDevice.turnOn();
        genericDevice.displayStatus();

        livingRoomLight.turnOn();
        livingRoomLight.setBrightness(85);
        livingRoomLight.displayStatus();

        bedroomColorLight.turnOn();
        bedroomColorLight.setBrightness(65);
        bedroomColorLight.setColor("Red");
        bedroomColorLight.displayStatus();

        livingRoomAC.turnOn();
        livingRoomAC.setTemperature(22);
        livingRoomAC.displayStatus();

        garageCooler.turnOn();
        garageCooler.setTemperature(25);
        garageCooler.setFanSpeed("High");
        garageCooler.displayStatus();
    }
}
