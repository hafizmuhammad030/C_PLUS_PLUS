class SmartLight {
    protected String name;
    protected boolean isOn;
    protected int brightness;

    SmartLight(String name) {
        this.name = name;
        this.isOn = false;
        this.brightness = 0;
    }

    void turnOn() {
        isOn = true;
        System.out.println(name + " is turned ON.");
    }

    void turnOff() {
        isOn = false;
        System.out.println(name + " is turned OFF.");
    }

    void setBrightness(int brightness) {
        this.brightness = brightness;
        System.out.println(name + " brightness set to " + brightness + "%.");
    }

    void displayStatus() {
        System.out.println("Device: " + name + " | Status: " + (isOn ? "ON" : "OFF") + " | Brightness: " + brightness + "%");
    }
}

class SmartColorLight extends SmartLight {
    private String color;

    SmartColorLight(String name, String color) {
        super(name);
        this.color = color;
    }

    void setColor(String color) {
        this.color = color;
        System.out.println(name + " color set to " + color + ".");
    }

    @Override
    void displayStatus() {
        System.out.println("Device: " + name + " | Status: " + (isOn ? "ON" : "OFF") + " | Brightness: " + brightness + "% | Color: " + color);
    }
}

public class Main1 {
    public static void main(String[] args) {
        SmartColorLight bedroomLight = new SmartColorLight("Bedroom Light", "White");
        bedroomLight.turnOn();
        bedroomLight.setBrightness(50);
        bedroomLight.setColor("Blue");
        bedroomLight.displayStatus();
    }
}
