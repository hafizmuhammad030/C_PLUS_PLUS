class SmartDevice {
    protected String deviceName;
    protected boolean isOn;

    public SmartDevice(String deviceName) {
        this.deviceName = deviceName;
        this.isOn = false;
    }

    public void turnOn() {
        isOn = true;
    }

    public void turnOff() {
        isOn = false;
    }

    public void displayStatus() {
        String status = isOn ? "ON" : "OFF";
        System.out.println("Device: " + deviceName + " | Status: " + status);
    }
}

class SmartLight extends SmartDevice {
    private int brightness;

    public SmartLight(String deviceName) {
        super(deviceName);
        this.brightness = 0;
    }

    public void setBrightness(int level) {
        if (level >= 0 && level <= 100) {
            brightness = level;
            System.out.println(deviceName + " brightness set to " + brightness + "%.");
        } else {
            System.out.println("Brightness level must be between 0 and 100.");
        }
    }

    @Override
    public void displayStatus() {
        String status = isOn ? "ON" : "OFF";
        System.out.println("Device: " + deviceName + " | Status: " + status + " | Brightness: " + brightness + "%");
    }
}

public class Main4 {
    public static void main(String[] args) {
        SmartLight livingRoomLight = new SmartLight("Living Room Light");
        livingRoomLight.turnOn();
        livingRoomLight.setBrightness(75);
        livingRoomLight.displayStatus();
    }
}
